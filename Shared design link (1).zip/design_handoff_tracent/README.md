# Handoff: Tracent Marketplace

## Overview
Tracent is an AI agent marketplace: browse/list agents, company & individual profiles, account creation, and account management. This bundle covers the full site's HTML design references.

## About the Design Files
The files here are **design references built in HTML** (prototypes), not production code. They demonstrate intended visual design, layout, copy, and interaction behavior. Recreate these designs in the target codebase's existing framework/environment (React, Vue, etc.) using its established component and state patterns. If no framework exists yet, pick the most suitable one for the project. Do not ship this HTML directly.

## Fidelity
**High-fidelity.** Colors, type, spacing, and states are final; recreate pixel-accurately.

## Design Tokens

**Colors**
- Background (global): `#050C13`
- Surface / card: `rgba(244,247,243,.05)` on navy, border `rgba(244,247,243,.12)`
- Primary text: `#F4F7F3`
- Secondary text: `rgba(244,247,243,.55–.6)`
- Cyan accent (Individual / interactive highlight): `#35C0B0`, hover `#6BD9CB`
- Individual-selection cyan variant: `#22D3EE`
- Blue accent (business / CTAs): `#072AC8` → gradient to `#2f4fe0` / `#4D7CFF`
- Error/destructive: `#EF233C`
- Dark seal shade: `#1F8A7E`

**Typography**
- Display/headings: `Space Grotesk` (500/600/700)
- Body: `CothamSansRegular`, fallback `Inter`, system-ui
- Monospace (emails, addresses): `ui-monospace, Menlo, monospace`

**Spacing / shape**
- Border radius: `4px` standard (`3px` on small chips/tags)
- Card padding: `36px 34px` (auth cards), `18–20px` (list rows)
- Progress step bar: 6 segments, `36px` wide `3px` tall, `#35C0B0` active / `rgba(244,247,243,.15)` inactive

**Effects**
- Glass cards: `backdrop-filter: blur(20px)`, shadow `0 30px 70px rgba(0,0,0,.45), inset 0 1px 0 rgba(255,255,255,.06)`
- Ambient glow blobs: radial gradients, blurred, subtle pulse animation (6–7s loop)

## Verification badge
A single scalloped-seal icon (3-piece clip-path polygon shield in cyan tones) is used everywhere a "verified" badge appears — keep this consistent across all pages.

## Pages

### Landing.dc.html
Marketing/search home. Nav with logo, sign-in link. Company/agent search demo cards with logos, descriptions, industries.

### Marketplace.dc.html
Agent listing grid with pagination and industry filter tags. Dark navy background throughout.

### Profile.dc.html / User Profile.dc.html / Agent Profile.dc.html
Public-facing profile pages for companies, individuals, and agents respectively. Verification seal, bio, connected accounts, listed agents/favorites.

### Create Account.dc.html
Multi-step signup, **step order for individuals**: 1) role selection (Individual/Business, cyan highlight + custom white-outline icons) → 2) account details (name/email/password) → 3) AI experience level (Beginner/Intermediate/Advanced) → 4) best-use-case free-text (2-3 sentences) → 5) two-step email verification → 6) purpose tags → 7) profile setup (bio, connected accounts, favorites/agents) → 8) confirmation (smiley-face icon, replaces old seal on this screen only).
**Business path** skips steps 3 and 4, going straight from account details to verification.
Progress bar renders 6 segments driven by a `step` state value (uses `1.5`/`1.75` as sub-steps between 1 and 2 conceptually, i.e. non-integer step values gate which panel shows).

### Create Agent.dc.html
Flow for listing/importing an agent onto a profile.

### Settings.dc.html
Account settings/preferences.

### Reset Password.dc.html
Password reset flow.

### Contact.dc.html
Contact form/support page.

## Key Interaction Notes
- Role selection cards: unselected = white icon on `rgba(244,247,243,.03)`; selected = cyan icon/border/dot fill, `#22D3EE` for Individual and `#35C0B0` tint used elsewhere for verified/cyan accents (Individual uses `#22D3EE` specifically for its selected state in Create Account).
- All "Continue" buttons: enabled state = `linear-gradient(135deg,#072AC8,#2f4fe0)` white text; disabled = `rgba(244,247,243,.08)` bg, `rgba(244,247,243,.4)` text, cursor default.
- Terms checkbox: custom 17px box, cyan when checked with dark checkmark.
- OTP verification: 6 separate 1-digit inputs, auto error state styling on mismatch (`#EF233C` message).

## Assets
Icons are custom white-outline SVGs (inline, not files) built to match Figma vectors where available. Third-party logos (Google, GitHub, X, LinkedIn, Hugging Face, Product Hunt) are PNG/SVG files referenced from `assets/`.

## Files
See the `.dc.html` files in this folder — one per page, matching the filenames above.
